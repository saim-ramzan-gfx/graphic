import { Palette, Layout, Lightbulb, Rocket } from 'lucide-react';

const steps = [
  {
    icon: Lightbulb,
    title: "Discovery",
    description: "Understanding your brand, goals, and target audience through in-depth research and consultation."
  },
  {
    icon: Palette,
    title: "Design Concepts",
    description: "Creating multiple design directions that align with your brand strategy and objectives."
  },
  {
    icon: Layout,
    title: "Refinement",
    description: "Iterating and perfecting the chosen design direction based on your feedback."
  },
  {
    icon: Rocket,
    title: "Launch",
    description: "Delivering final assets and providing support for implementation."
  }
];

export default function Process() {
  return (
    <div className="pt-16">
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-12">Design Process</h1>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-sm">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <step.icon className="text-blue-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}