import { PenTool, Monitor, Megaphone } from 'lucide-react';

const services = [
  {
    icon: PenTool,
    title: "Brand Identity",
    description: "Logo design, color palettes, typography, and comprehensive brand guidelines.",
    price: "Starting at $2,500"
  },
  {
    icon: Monitor,
    title: "Web Design",
    description: "Custom website design, UI/UX design, responsive layouts, and prototypes.",
    price: "Starting at $3,500"
  },
  {
    icon: Megaphone,
    title: "Marketing Design",
    description: "Social media graphics, digital ads, print materials, and campaign assets.",
    price: "Starting at $1,500"
  }
];

export default function Services() {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-12">Services</h1>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="border border-gray-200 rounded-xl p-8 hover:border-blue-500 transition-colors">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                  <service.icon className="text-blue-600" size={24} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <p className="text-blue-600 font-semibold">{service.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}