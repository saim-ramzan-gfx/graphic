import { ExternalLink } from 'lucide-react';

const projects = [
  {
    title: "Brand Identity - Eco Foods",
    category: "Branding",
    image: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=1000",
    link: "#"
  },
  {
    title: "Web Design - Tech Startup",
    category: "UI/UX Design",
    image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&q=80&w=1000",
    link: "#"
  },
  {
    title: "Social Media Campaign",
    category: "Digital Marketing",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=1000",
    link: "#"
  }
];

export default function Work() {
  return (
    <div className="pt-16">
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-12">Selected Works</h1>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="group relative overflow-hidden rounded-xl">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-[400px] object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute bottom-0 p-6 text-white">
                    <p className="text-sm mb-2">{project.category}</p>
                    <h3 className="text-xl font-semibold mb-4">{project.title}</h3>
                    <a href={project.link} className="inline-flex items-center gap-2 text-blue-300 hover:text-blue-200">
                      View Project <ExternalLink size={16} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}