import { Instagram, Twitter, Dribbble } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 mb-4 md:mb-0">© 2024 Sarah.Design. All rights reserved.</p>
          <div className="flex space-x-6">
            <a href="https://instagram.com" className="text-gray-600 hover:text-blue-500">
              <Instagram />
            </a>
            <a href="https://twitter.com" className="text-gray-600 hover:text-blue-500">
              <Twitter />
            </a>
            <a href="https://dribbble.com" className="text-gray-600 hover:text-blue-500">
              <Dribbble />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}